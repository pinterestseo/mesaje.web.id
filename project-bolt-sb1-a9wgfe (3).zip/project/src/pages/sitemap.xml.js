import { defineCollection, z } from 'astro:content';

export async function GET({ site }) {
  const pages = [
    '',
    'recent',
    'popular',
    'categories',
    'question/what-is-astro',
    'question/what-is-blockchain',
    'question/how-to-start-business',
    'question/how-to-learn-programming',
    'question/what-is-machine-learning'
  ];

  return new Response(
    `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      ${pages.map((page) => `
        <url>
          <loc>${site}/${page}</loc>
          <lastmod>${new Date().toISOString()}</lastmod>
          <changefreq>weekly</changefreq>
          <priority>${page === '' ? '1.0' : '0.7'}</priority>
        </url>
      `).join('')}
    </urlset>`,
    {
      headers: {
        'Content-Type': 'application/xml'
      }
    }
  );
}